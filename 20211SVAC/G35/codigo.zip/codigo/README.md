# Proyecto grupo 35

## Vacaciones de Junio 2021

Repositorio donde se publicarán el proyecto alpha sin enunciado


#### Paso 1: Instalación 
se debe hacer la instalacion por medio del siguiente comando

``` sh 
    npm i 
```
#### Paso 2: Levantar el proyecto
se debe hacer levantar por medio del siguiente comando

``` sh 
    quasar dev
```
### Paso 3
- Crear Gramatica XML
- Crear Gramatica XPATH
- Leer archivo XML

Para la interfaz gráfica queda a libertad del estudiante la utilización de cualquier framework web para la generación de su sitio

### Creación de pagina web

Para crear la pagina que se subirá en la página oficial del ingeniero se hara a través del siguiente comando

``` sh 
    quasar build
```

La pagina html se crea en el folder dist