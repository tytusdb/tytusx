export default class metodoC3D{
    parametros:number;
    linea:number;
    constructor(NumeroAtributos, Linea){
        this.parametros = NumeroAtributos;
        this.linea = Linea;
    }
}