export const enum TIPOS {
  STRING,
  NUMBER,
  BOOLEAN,
  TYPE,
  SIN_ASIGNAR,
  VOID
}
