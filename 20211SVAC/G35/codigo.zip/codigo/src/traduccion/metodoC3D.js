"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class metodoC3D {
    constructor(NumeroAtributos, Linea) {
        this.parametros = NumeroAtributos;
        this.linea = Linea;
    }
}
exports.default = metodoC3D;
