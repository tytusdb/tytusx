"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asign = void 0;
class asign {
    constructor(id, idd, linea) {
        this.id1 = id;
        this.id2 = idd;
        this.linea = linea;
    }
}
exports.asign = asign;
