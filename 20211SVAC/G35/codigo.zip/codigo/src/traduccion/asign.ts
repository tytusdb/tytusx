export class asign{
    id1:string;
    id2:string;
    linea:number;
    constructor(id, idd, linea){
        this.id1 = id;
        this.id2=idd;
        this.linea=linea;
    }
}