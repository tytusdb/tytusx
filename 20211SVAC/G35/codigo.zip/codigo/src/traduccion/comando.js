"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.comando = void 0;
class comando {
    constructor(id, li, go) {
        this.id = id;
        this.linea = li;
        this.goto = go;
    }
}
exports.comando = comando;
