//0=error
//1=numero
//2=cadena
//3=booleano
//4=etiqueta
//5=funcion
//6=arreglo
export const enum TIPO_DATO {
    ERROR,NUMBER,STRING, BOOLEAN, ETIQUETA, FUNCION, ARREGLO
}