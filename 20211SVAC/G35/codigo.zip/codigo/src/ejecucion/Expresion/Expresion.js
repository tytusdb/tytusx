"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Expresion = void 0;
class Expresion {
    constructor({ tipo_, valor_ }) {
        this.tipo = tipo_;
        this.valor = valor_;
    }
}
exports.Expresion = Expresion;
