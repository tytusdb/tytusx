"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reglaGramatical = void 0;
class reglaGramatical {
    constructor({ produccion, regla }) {
        Object.assign(this, { produccion, regla });
    }
}
exports.reglaGramatical = reglaGramatical;
